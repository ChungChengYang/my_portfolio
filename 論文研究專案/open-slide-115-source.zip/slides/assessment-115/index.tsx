import type { CSSProperties, ReactNode } from 'react';
import { useSlidePageNumber } from '@open-slide/core';
import type { DesignSystem, Page, SlideMeta } from '@open-slide/core';

export const design: DesignSystem = {
  palette: { bg: '#ffffff', text: '#171717', accent: '#8c2028' },
  fonts: {
    display: '"Noto Sans CJK TC", "Microsoft JhengHei", sans-serif',
    body: '"Noto Sans CJK TC", "Microsoft JhengHei", sans-serif',
  },
  typeScale: { hero: 66, body: 32 },
  radius: 0,
};

const root: CSSProperties = {
  width: '100%', height: '100%', position: 'relative', boxSizing: 'border-box',
  padding: '80px 100px', background: 'var(--osd-bg)', color: 'var(--osd-text)',
  fontFamily: 'var(--osd-font-body)', fontSize: 'var(--osd-size-body)',
  lineHeight: 1.5,
};
const p: CSSProperties = { margin: '0 0 22px', fontSize: 'var(--osd-size-body)', lineHeight: 1.5 };
const red: CSSProperties = { color: 'var(--osd-accent)', fontWeight: 800 };

function Header({ label, title }: { label: string; title: string }) {
  return <header>
    <div style={{ fontSize: 25, letterSpacing: 4, color: '#555', marginBottom: 20 }}>{label}</div>
    <h1 style={{ fontFamily: 'var(--osd-font-display)', fontSize: 'var(--osd-size-hero)', fontWeight: 800, lineHeight: 1.2, margin: 0 }}>{title}</h1>
    <div style={{ height: 5, background: 'var(--osd-accent)', marginTop: 28 }} />
  </header>;
}

function Footer() {
  const { current, total } = useSlidePageNumber();
  return <footer style={{ position: 'absolute', bottom: 42, left: 100, right: 100, borderTop: '1px solid #cfcfcf', paddingTop: 18, display: 'flex', justifyContent: 'space-between', fontSize: 24, color: '#555' }}>
    <span>管理處｜115年度考核新制重點說明</span>
    <span>{String(current).padStart(2, '0')} / {String(total).padStart(2, '0')}</span>
  </footer>;
}

function Section({ number, title, children, style }: { number: string; title: string; children: ReactNode; style?: CSSProperties }) {
  return <section style={style}>
    <h2 style={{ margin: '0 0 24px', fontSize: 36, lineHeight: 1.35, fontWeight: 800, display: 'flex', alignItems: 'baseline', gap: 18 }}>
      <span style={{ color: 'var(--osd-accent)', fontSize: 27, fontWeight: 700 }}>{number}</span>{title}
    </h2>
    {children}
  </section>;
}

const Policy: Page = () => <main style={root} lang="zh-Hant">
  <Header label="制度調整與適用原則" title="管理處115年度考核新制及作業重點" />
  <div style={{ marginTop: 34, padding: '24px 32px', background: '#faf5f5', borderLeft: '7px solid var(--osd-accent)', display: 'flex', alignItems: 'center', gap: 40 }}>
    <div style={{ ...red, fontSize: 46, whiteSpace: 'nowrap' }}>取消甲等75%比例限制</div>
    <div style={{ fontSize: 32, borderLeft: '1px solid #d8bfc1', paddingLeft: 40 }}>不再預先分配甲等名額<br /><strong>取消比例限制，仍須覈實評定。</strong></div>
  </div>
  <div style={{ display: 'grid', gridTemplateColumns: '530px 530px 580px', gap: 40, marginTop: 44 }}>
    <Section number="一" title="函釋及法規依據">
      <p style={p}>銓敘部115年10月30日<br />部銓三字第11560308292號函。</p>
      <p style={p}>行政院人事行政總處<br />115年11月4日<br />總處綜字第1151001959號書函。</p>
      <p style={p}>《農田水利事業人員<br />人事管理辦法》第80條。</p>
    </Section>
    <Section number="二" title="管理處適用方式" style={{ borderLeft: '1px solid #ddd', paddingLeft: 32 }}>
      <p style={{ ...p, marginBottom: 32 }}><strong>農田水利事業人員</strong><br />依《農田水利事業人員人事管理辦法》第80條，參照公務人員考績規定辦理。</p>
      <p style={p}><strong>管理處技術工、工友</strong><br />依行政院人事行政總處函釋，比照公務人員做法辦理考核。</p>
    </Section>
    <Section number="三" title="甲等評定原則" style={{ borderLeft: '1px solid #ddd', paddingLeft: 32 }}>
      <p style={p}>甲等人數<strong style={red}>得超過75%</strong>，<br />但不要求達到特定比例。</p>
      <p style={p}>取消比例限制<strong style={red}>不代表放寬<br />甲等標準</strong>。</p>
      <p style={p}>仍應依規定之比較範圍，審酌平時考核、具體優良事蹟及整體工作表現，覈實評定考核等次。</p>
    </Section>
  </div>
  <Footer />
</main>;

const Operations: Page = () => <main style={root} lang="zh-Hant">
  <Header label="考評注意事項與人資執行" title="考核特別注意事項及人資作業" />
  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gridTemplateRows: '350px 310px', columnGap: 44, rowGap: 26, marginTop: 34 }}>
    <Section number="一" title="依法請假不得影響考評" style={{ padding: '24px 28px', border: '1px solid #d2d2d2', borderTop: '5px solid var(--osd-accent)' }}>
      <p style={{ ...p, marginBottom: 16 }}>家庭照顧假、身心調適假、生理假、婚假、產前假、娩假、流產假、陪產檢及陪產假、因安胎事由所請之假及病假等，<strong style={red}>不得作為考核等次之考量因素</strong>。</p>
      <p style={{ ...p, marginBottom: 0 }}>仍應依受考人<strong>實際工作績效</strong>覈實考評。</p>
    </Section>
    <Section number="二" title="違失行為應審慎評定" style={{ padding: '24px 28px', border: '1px solid #d2d2d2', borderTop: '5px solid var(--osd-accent)' }}>
      <p style={{ ...p, marginBottom: 24 }}>酒後駕車、性騷擾及職場霸凌等違失，<br />應依規定<strong style={red}>即時辦理懲處</strong>。</p>
      <p style={p}>應依<strong>具體事證</strong>，審慎評定<br />當年度考核等次。</p>
    </Section>
    <Section number="三" title="人資室配合事項" style={{ padding: '20px 28px', background: '#f6f6f6' }}>
      <p style={{ ...p, marginBottom: 12 }}>修正內部考核作業及宣導文字。</p>
      <p style={{ ...p, marginBottom: 12 }}>提醒主管<strong style={red}>不得按比例分配甲等</strong>。</p>
      <p style={{ ...p, marginBottom: 0 }}>完備平時考核及具體事蹟紀錄，<br />留存考評依據。</p>
    </Section>
    <Section number="四" title="表件及程序提醒" style={{ padding: '20px 28px', background: '#f6f6f6' }}>
      <p style={{ ...p, marginBottom: 18 }}>考績人數統計表及甲等人數比率分配<br />彙整表，仍依現行方式填報。</p>
      <p style={{ ...p, marginBottom: 0 }}>確認考核程序、核定權責及作業期限。</p>
    </Section>
  </div>
  <Footer />
</main>;

export const meta: SlideMeta = {
  title: '管理處115年度考核新制重點說明',
  createdAt: '2026-11-11T15:51:02.646Z',
};

export const notes: (string | undefined)[] = [
  '本頁依提供之簡報大綱編排。函號、日期及制度內容尚未另行查核原函。說明時請強調：取消甲等75%比例限制，不再預先分配名額；得超過75%，但不要求達到特定比例，也不代表放寬甲等標準。兩類人員分別依其適用依據辦理。',
  '本頁依提供之簡報大綱編排。依法請假不列為等次考量，仍以實際工作績效覈實考評。違失應依規定即時辦理懲處，並依具體事證審慎評定。請人資室同步修正作業及宣導文字，留存考評依據；表件仍依現行方式填報，並確認程序、核定權責及作業期限。',
];

export default [Policy, Operations] satisfies Page[];
